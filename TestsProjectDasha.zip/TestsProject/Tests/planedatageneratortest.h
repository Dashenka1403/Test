#ifndef PLANEDATAGENERATORTEST_H
#define PLANEDATAGENERATORTEST_H

#include "string"
#include "../data/PlaneDataGenerator.h"
class PlaneDataGeneratorTests
{
    double _previousFuelLevel;
    double _previousAltitude;
    double _previousAttakAngle;

    double _currentFuelLevel;
    double _currentAltitude;
    double _currentAttakAngle;

    const double MAX_FUEL_CONSUMPTION = 3;
    const double MAX_CHANGING_HIGH = 60;
    const double MAX_CHANGING_ANGLE = 10;
    double _step;

    PlaneDataGenerator* _generator;
private:
    bool validateFuelLevel(double fuelLevel);
    bool validateFuelLevel(std::string& error);
    bool validateAltitude(std::string&);
    bool validateAltitude(double altitude);
    bool validateAttakAngle(std::string&);
    bool validateAttakAngle(double attakAngle);
    std::string generateFuelLevelErrorLog(std::string error);
    std::string generateAltitudeErrorLog(std::string error);
    std::string generateAttakAngleErrorLog(std::string error);
    void writeLogOnDisk(std::string log, std::ofstream&);
public:
    PlaneDataGeneratorTests();
    void initRandom(double);
    void initLimited(double, double, double, double, double, double, double);
    void initConcrete(double, double, double, double);
    bool runTests(double duration);
    ~PlaneDataGeneratorTests();
};
#endif // PLANEDATAGENERATORTEST_H
