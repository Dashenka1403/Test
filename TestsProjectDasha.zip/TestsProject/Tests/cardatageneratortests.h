#ifndef CARDATAGENERATORTESTS_H
#define CARDATAGENERATORTESTS_H

#include "../data/CarDataGenerator.h"
#include "string"

class CarDataGeneratorTests
{
    double _previousSpeed;
    double _previousFuelLevel;
    double _previousTemperature;
    double _previousRotationalSpeed;

    double _currentSpeed;
    double _currentFuelLevel;
    double _currentTemperature;
    double _currentRotationalSpeed;

    const double MAX_ACCELERATION_PER_SECOND = 50;
    const double MAX_BRAKING_PER_SECOND = 70;
    const double MAX_FUEL_CONSUMPTION = 0.0062;
    const double MAX_TEMPERATURE_CHANGING = 30;

    double _step;
    CarDataGenerator* _generator;
private:
    bool validateSpeed(std::string&);
    bool validateSpeed(double speed);
    bool validateFuelLevel(double fuelLevel);
    bool validateFuelLevel(std::string& error);
    bool validateTemperature(std::string&);
    bool validateTemperature(double temperature);
    bool validateRotationalSpeed(std::string&);
    bool validateRotationalSpeed(double rotationalSpeed);
    std::string generateSpeedErrorLog(std::string);
    std::string generateFuelLevelErrorLog(std::string error);
    std::string generateTemperatureErrorLog(std::string error);
    std::string generateRotationalSpeedErrorLog(std::string error);
    void writeLogOnDisk(std::string log, std::ofstream&);
public:
    CarDataGeneratorTests();
    void initRandom(double);
    void initLimited(double, double, double, double, double, double, double, double, double);
    void initConcrete(double, double, double, double, double);
    bool runTests(double duration);
    ~CarDataGeneratorTests();
};

#endif // CARDATAGENERATORTESTS_H
