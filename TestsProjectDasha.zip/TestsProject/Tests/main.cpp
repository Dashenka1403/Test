#include "iostream"
#include "cardatageneratortests.h"
int main(int argc, char *argv[])
{
    std::cout << "Running tests..." << std::endl;
    CarDataGeneratorTests test;
    test.initRandom(0.1);
    test.runTests(1000000);
    std::cout << "Tests done!" << std::endl;
}
