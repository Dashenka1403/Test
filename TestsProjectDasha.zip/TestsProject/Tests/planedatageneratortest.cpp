#include "planedatageneratortest.h"
#include "fstream"

PlaneDataGeneratorTests::PlaneDataGeneratorTests()
{

}

void PlaneDataGeneratorTests::initRandom(double step)
{
    _generator = new PlaneDataGenerator(step);
    _step = step;
}

void PlaneDataGeneratorTests::initLimited(double step, double minFuelLevel, double maxFuelLevel, double minAltitude, double maxAltitude, double minAttakAngle, double maxAttakAngle)
{
    _generator = new PlaneDataGenerator(step, minFuelLevel, maxFuelLevel, minAltitude, maxAltitude, maxAttakAngle, minAttakAngle);
    _step = step;
}

void PlaneDataGeneratorTests::initConcrete(double step, double fuelLevel, double altitude, double attakAngle)
{
    _generator = new PlaneDataGenerator(step, fuelLevel, altitude, attakAngle);
    _step = step;
}

bool PlaneDataGeneratorTests::runTests(double duration)
{
    std::ofstream logFile("logs.txt");
    std::string error;
    std::string log;
    bool testStatus = true;

    size_t count = duration / _step;

    for(size_t i = 0; i < count; i++)
    {
        _previousFuelLevel = _generator->getFuelLevel();
        _previousAltitude = _generator->getAltitude();
        _previousAttakAngle = _generator->getAttakAngle();

        _generator->compute();

        _currentFuelLevel = _generator->getFuelLevel();
        _currentAltitude = _generator->getAltitude();
        _currentAttakAngle = _generator->getAttakAngle();

    }

    if (validateFuelLevel(error) == false)
    {
        log = generateFuelLevelErrorLog(error);
        writeLogOnDisk(log, logFile);
        testStatus = false;
    }

    if (validateAltitude(error) == false)
    {
        log = generateAltitudeErrorLog(error);
        writeLogOnDisk(log, logFile);
        testStatus = false;
    }

    if (validateAttakAngle(error) == false)
    {
        log = generateAttakAngleErrorLog(error);
        writeLogOnDisk(log, logFile);
        testStatus = false;
    }

     return testStatus;
}

bool PlaneDataGeneratorTests::validateFuelLevel(std::string& error)
{
    error.clear();

    if (_currentFuelLevel - _previousFuelLevel > MAX_FUEL_CONSUMPTION*_step)
        error += "Consumption of fuel in the plane is too large!\n";
    // нет проверки на выход за пределы диапазона
    if (validateFuelLevel(_previousFuelLevel)&&validateFuelLevel(_previousFuelLevel) == false)
        error += "level of fuel is out of range!\n";

    return error.empty();
}

bool PlaneDataGeneratorTests::validateAltitude(std::string& error)
{
    error.clear();

    if (_currentAltitude - _previousAltitude > MAX_CHANGING_HIGH*_step)
        error += "Altitude of the plane is too large!\n";
    // нет проверки на выход за пределы диапазона
    if (validateAltitude(_previousAltitude)&&validateAltitude(_previousAltitude) == false)
        error += "Altitude is out of range!\n";

    return error.empty();
}

bool PlaneDataGeneratorTests::validateAttakAngle(std::string& error)
{
    error.clear();

    if (_currentAttakAngle - _previousAttakAngle > MAX_CHANGING_ANGLE*_step)
        error += "Attak Angle of the plane is too large!\n";
    // нет проверки на выход за пределы диапазона
    if (validateAltitude(_previousAttakAngle)&&validateAltitude(_previousAttakAngle) == false)
        error += "Attak Angle is out of range!\n";

    return error.empty();
}

bool PlaneDataGeneratorTests::validateFuelLevel(double fuelLevel)
{
    return fuelLevel >=0 && fuelLevel<=13000;
}

bool PlaneDataGeneratorTests::validateAltitude(double altitude)
{
    return altitude >=0 && altitude<=13000;
}

bool PlaneDataGeneratorTests::validateAttakAngle(double attakAngle)
{
    return attakAngle >=-15 && attakAngle<=15;
}

std::string PlaneDataGeneratorTests::generateFuelLevelErrorLog(std::string error)
{
    std::string log;
    log += "Previous Fuel Level: ";
    log += std::to_string(_previousFuelLevel);
    log += " l\nCurrent Fuel Level: ";
    log += std::to_string(_currentFuelLevel);
    log += "\nError:\n";
    log += error;
    log += '\n';
    return log;
}

std::string PlaneDataGeneratorTests::generateAltitudeErrorLog(std::string error)
{
    std::string log;
    log += "Previous Altitude: ";
    log += std::to_string(_previousAltitude);
    log += " l\nCurrent Altitude: ";
    log += std::to_string(_currentAltitude);
    log += "\nError:\n";
    log += error;
    log += '\n';
    return log;
}

std::string PlaneDataGeneratorTests::generateAttakAngleErrorLog(std::string error)
{
    std::string log;
    log += "Previous Attak Angle: ";
    log += std::to_string(_previousAttakAngle);
    log += " l\nCurrent Attak Angle: ";
    log += std::to_string(_currentAttakAngle);
    log += "\nError:\n";
    log += error;
    log += '\n';
    return log;
}

void PlaneDataGeneratorTests::writeLogOnDisk(std::string log, std::ofstream& stream)
{
    stream << log;
}


PlaneDataGeneratorTests::~PlaneDataGeneratorTests()
{
    delete _generator;
}

