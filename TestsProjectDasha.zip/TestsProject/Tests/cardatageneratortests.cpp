#include "cardatageneratortests.h"
#include "fstream"

CarDataGeneratorTests::CarDataGeneratorTests()
{

}

void CarDataGeneratorTests::initRandom(double step)
{
    _generator = new CarDataGenerator(step);
    _step = step;
}

void CarDataGeneratorTests::initLimited(double step, double minSpeed, double maxSpeed, double minFuelLevel, double maxFuelLevel, double minTemperature, double maxTemperature, double minRotationalSpeed, double maxRotationalSpeed)
{
    _generator = new CarDataGenerator(step, minSpeed, maxSpeed, minFuelLevel, maxFuelLevel, minTemperature, maxTemperature, maxRotationalSpeed, minRotationalSpeed);
    _step = step;
}

void CarDataGeneratorTests::initConcrete(double step, double speed, double fuelLevel, double temperature, double rotationalSpeed)
{
    _generator = new CarDataGenerator(step, speed, fuelLevel, temperature, rotationalSpeed);
    _step = step;
}

bool CarDataGeneratorTests::runTests(double duration)
{
    std::ofstream logFile("logs.txt");
    std::string error;
    std::string log;
    bool testStatus = true;

    size_t count = duration / _step;

    for(size_t i = 0; i < count; i++)
    {
        _previousSpeed = _generator->getSpeed();
        _previousFuelLevel = _generator->getFuelLevel();
        _previousTemperature = _generator->getTemperatur();
        _previousRotationalSpeed = _generator->getRotationalSpeed();

        _generator->compute();

        _currentSpeed = _generator->getSpeed();
        _currentFuelLevel = _generator->getFuelLevel();
        _currentTemperature = _generator->getTemperatur();
        _currentRotationalSpeed = _generator->getRotationalSpeed();

        if (validateSpeed(error) == false)
        {
            log = generateSpeedErrorLog(error);
            writeLogOnDisk(log, logFile);
            testStatus = false;
        }
        // отсутствовали проверки на неправильные данные
        if (validateFuelLevel(error) == false)
        {
            log = generateFuelLevelErrorLog(error);
            writeLogOnDisk(log, logFile);
            testStatus = false;
        }
        if (validateTemperature(error) == false)
        {
            log = generateTemperatureErrorLog(error);
            writeLogOnDisk(log, logFile);
            testStatus = false;
        }
        if (validateRotationalSpeed(error) == false)
        {
            log = generateRotationalSpeedErrorLog(error);
            writeLogOnDisk(log, logFile);
            testStatus = false;
        }
    }

    logFile.close();
    return testStatus;
}

bool CarDataGeneratorTests::validateSpeed(std::string& error)
{
    error.clear();

    if (validateSpeed(_previousSpeed)&&validateSpeed(_currentSpeed) == false)
        error += "speed is out of range!\n";

    // изменить по аналогии с другими блоками if и в других методах для валидации, которые формируют ошибку
    if (_currentSpeed - _previousSpeed > MAX_ACCELERATION_PER_SECOND*_step)
    {
        error += "acceleration of the car is too large: ";
        error += std::to_string((_currentSpeed - _previousSpeed)/_step); // вывести разницу между предыдущим и текущим значениями
        error += "km/h^2\n"; // вывести единицу измерения
    }

    if (_previousSpeed - _currentSpeed > MAX_BRAKING_PER_SECOND*_step)
        error += "braking of the car is too large!\n";

    return error.empty();
}
bool CarDataGeneratorTests::validateFuelLevel(std::string& error)
{
    error.clear();

    if (_currentFuelLevel - _previousFuelLevel > MAX_FUEL_CONSUMPTION*_step)
        error += "Consumption of fuel in the car is too large!\n";
    // нет проверки на выход за пределы диапазона
    if (validateFuelLevel(_previousFuelLevel)&&validateFuelLevel(_previousFuelLevel) == false)
        error += "level of fuel is out of range!\n";

    return error.empty();
}

bool CarDataGeneratorTests::validateTemperature(std::string& error)
{
    error.clear();

    if (_currentTemperature - _previousTemperature > MAX_TEMPERATURE_CHANGING*_step)
        error += "Temperature of motor in the car is too large!\n";
    // нет проверки на выход за пределы диапазона
    if (validateTemperature(_previousTemperature)&&validateTemperature(_previousTemperature) == false)
        error += "engine temperature is out of range!\n";

    return error.empty();
}
// не был написан метод генерации ошибки для оборотов двигателя
bool CarDataGeneratorTests::validateRotationalSpeed(std::string& error)
{
    error.clear();

    if (validateRotationalSpeed(_previousRotationalSpeed)&&validateRotationalSpeed(_currentRotationalSpeed) == false)
        error += "engine RPM is out of range!\n";

    return error.empty();
}

bool CarDataGeneratorTests::validateSpeed(double speed)
{
    return speed >= 0 && speed <= 200;
}

bool CarDataGeneratorTests::validateFuelLevel(double fuelLevel)
{
    return fuelLevel >=0 && fuelLevel<=50;
}

bool CarDataGeneratorTests::validateTemperature(double temperature)
{
    return temperature >=-25 && temperature<=85;
}

bool CarDataGeneratorTests::validateRotationalSpeed(double rotationalSpeed)
{
    return rotationalSpeed >= 0 && rotationalSpeed<=6500;
}

std::string CarDataGeneratorTests::generateSpeedErrorLog(std::string error)
{
    std::string log;
    log += "Previous speed: ";
    log += std::to_string(_previousSpeed);
    log += " km/h\nCurrent speed: ";
    log += std::to_string(_currentSpeed);
    log += "\nError:\n";
    log += error;
    log += '\n';
    return log;
}

std::string CarDataGeneratorTests::generateFuelLevelErrorLog(std::string error)
{
    std::string log;
    log += "Previous Fuel Level: ";
    log += std::to_string(_previousFuelLevel);
    log += " l\nCurrent Fuel Level: ";
    log += std::to_string(_currentFuelLevel);
    log += "\nError:\n";
    log += error;
    log += '\n';
    return log;
}

std::string CarDataGeneratorTests::generateTemperatureErrorLog(std::string error)
{
    std::string log;
    log += "Previous Temperature: ";
    log += std::to_string(_previousTemperature);
    log += " C\nCurrent Temperature: ";
    log += std::to_string(_currentTemperature);
    log += "\nError: ";
    log += error;
    log += '\n';
    return log;
}

std::string CarDataGeneratorTests::generateRotationalSpeedErrorLog(std::string error)
{
    std::string log;
    log += "Previous RotationalSpeed: ";
    log += std::to_string(_previousRotationalSpeed);
    log += " C\nCurrent RotationalSpeed: ";
    log += std::to_string(_currentRotationalSpeed);
    log += "\nError:\n";
    log += error;
    log += '\n';
    return log;
}
void CarDataGeneratorTests::writeLogOnDisk(std::string log, std::ofstream& stream)
{
    stream << log;
}


CarDataGeneratorTests::~CarDataGeneratorTests()
{
    delete _generator;
}

